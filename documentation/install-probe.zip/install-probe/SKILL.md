---
name: install-probe
description: "Throwaway test for the Paloma's Orrery project. It checks whether an installed skill keeps the extra files in its folder. Use only when a session is asked to check the install probe. Delete it from Settings after the check (ledger L-418)."
---

# Install probe

Probe version: 1.0 | 2026-10-06, with Anthropic's Claude Opus 5.5, at
palomas_orrery @ fbd223ee. Not a working skill; never commit it to
skills/ in the repo, where skills_index.py would add it to the manifest.

This folder should hold one extra file, references/probe.md. A session
checking the install lists this folder and reads that file. The check
passes only if the file is there and its sentence is the one recorded
in documentation/HANDOFF_L418_skill_split_design_20261006.md.
