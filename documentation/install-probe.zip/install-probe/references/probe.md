Probe sentence: the extra file arrived with the skill. Token L418-probe-20261006-7c1d.
